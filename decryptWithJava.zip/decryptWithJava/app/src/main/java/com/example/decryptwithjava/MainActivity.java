package com.example.decryptwithjava;

import android.os.Bundle;
import android.util.Base64;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import androidx.activity.result.ActivityResultLauncher;
import androidx.appcompat.app.AppCompatActivity;
import com.google.zxing.Result;
import com.journeyapps.barcodescanner.ScanContract;
import com.journeyapps.barcodescanner.ScanOptions;
import java.nio.charset.StandardCharsets;
import java.security.InvalidAlgorithmParameterException;
import java.security.InvalidKeyException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.Arrays;
import javax.crypto.BadPaddingException;
import javax.crypto.Cipher;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;


public class MainActivity extends AppCompatActivity {
    private EditText passwordEditText;
    private Button decryptButton;
    private Button scanButton;
    TextView decryptedMessageTextView;
    String qrResult="";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Initialize UI elements
        scanButton = findViewById(R.id.scanButton);
        passwordEditText = findViewById(R.id.passwordEditText);
        decryptButton = findViewById(R.id.decryptButton);
        decryptedMessageTextView = findViewById(R.id.decryptedMessageTextView);

        scanButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                scanQr();
            }
        });
        // Set click listener for decrypt button
        decryptButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Get password from edit text
                String password = passwordEditText.getText().toString();

                // Check if password is empty
                if (password.isEmpty()) {
                    Toast.makeText(MainActivity.this, "Please enter a password", Toast.LENGTH_SHORT).show();
                    return;
                }

                // Get scanned QR code data
                if (qrResult == null) {
                    Toast.makeText(MainActivity.this, "No QR code scanned", Toast.LENGTH_SHORT).show();
                    return;
                }

                // Remove error code prefix
                String encryptedDataWithPrefix =qrResult;
                String encryptedData = encryptedDataWithPrefix.replace("error code: lmmziAGGcs18MD/pVHtV", "");

                // Decrypt QR code data
                String decryptedData = decrypt(encryptedData, password);

                // Display decrypted data
                if (decryptedData != null) {
                    Toast.makeText(MainActivity.this, "Decrypted message: " + decryptedData, Toast.LENGTH_LONG).show();
                    decryptedMessageTextView.setText(decryptedData);
                } else {
                    Toast.makeText(MainActivity.this, "Failed to decrypt message", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }
    public  void  scanQr()
    {
        ScanOptions options = new ScanOptions();
        options.setDesiredBarcodeFormats(ScanOptions.QR_CODE);
        options.setPrompt("Scan a barcode");
        options.setCameraId(0);
        options.setBeepEnabled(true);
        options.setBarcodeImageEnabled(true);

        barcodeLauncher.launch(options);
        decryptedMessageTextView.setText("");
    }
    private final ActivityResultLauncher<ScanOptions> barcodeLauncher = registerForActivityResult(new ScanContract(),
            result ->
            {
                if(result.getContents() == null)
                {
                    Toast.makeText(this, "Error Failed To Scan QR", Toast.LENGTH_SHORT).show();
                }
                else
                {
                    qrResult=result.getContents();
                    decryptedMessageTextView.setText(qrResult);



                }
            });
    // Method to decrypt data
    private String decrypt(String encryptedData, String password) {
        try {
            // Generate AES key from password
            MessageDigest digest = MessageDigest.getInstance("SHA-256");
            byte[] keyBytes = digest.digest(password.getBytes(StandardCharsets.UTF_8));
            SecretKeySpec key = new SecretKeySpec(keyBytes, "AES");

            // Get IV from encrypted data
            byte[] encryptedBytes = Base64.decode(encryptedData, Base64.DEFAULT);
            byte[] ivBytes = Arrays.copyOfRange(encryptedBytes, 0, 16);
            IvParameterSpec iv = new IvParameterSpec(ivBytes);

            // Perform AES decryption
            Cipher cipher = Cipher.getInstance("AES/CBC/PKCS5Padding");
            cipher.init(Cipher.DECRYPT_MODE, key, iv);

            byte[] decryptedBytes = cipher.doFinal(encryptedBytes, 16, encryptedBytes.length - 16);
            return new String(decryptedBytes, StandardCharsets.UTF_8);

        } catch (NoSuchAlgorithmException | NoSuchPaddingException |
                 InvalidKeyException | InvalidAlgorithmParameterException | IllegalBlockSizeException | BadPaddingException e) {e.printStackTrace();
            return null;
        }
    }
}
